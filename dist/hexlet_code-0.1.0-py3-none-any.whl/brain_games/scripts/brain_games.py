from brain_games.cli import welcome_user
from brain_games.calc import calc
from brain_games.even import even

def main():
    welcome_user()  # наша функция

if __name__ == '__main__':

    main()
