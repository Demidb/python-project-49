def main():
    print("Welcome to the Brain Games!")  # использовать здесь 
if __name__ == "__main__":
    main()
    if __name__ == "__main__":
        name = input()
        welcome_user('name') 