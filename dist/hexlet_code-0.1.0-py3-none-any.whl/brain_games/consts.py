EVEN_INSTUCTION = 'Answer "yes" if the number is even, otherwise answer "no".'
CALC_INSTUCTION = 'What is the result of the expression?'
GCD_INSTUCTION = 'Find the greatest common divisor of given numbers.'
PROGRESSION_INSTUCTION = 'What number is missing in the progression?'
PRIME_INSTUCTION = 'Answer "yes" if given number is prime. ' \
    'Otherwise answer "no".'
MATH_SIGNS = ('+', '-', '*')
MIN_PROGRESSION_LENGHT, MAX_PROGRESSION_LENGHT = 5, 10
AMOUNT_OF_ROUNDS = 3
