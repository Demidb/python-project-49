### Hexlet tests and linter status:
[![Actions Status](https://github.com/Demidb/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Demidb/python-project-49/actions)
<a href="https://codeclimate.com/github/Demidb/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/522cd74e06f4ba19bd53/maintainability" /></a> 