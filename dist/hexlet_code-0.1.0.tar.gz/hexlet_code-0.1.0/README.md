### Hexlet tests and linter status:
[![Actions Status](https://github.com/Demidb/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Demidb/python-project-49/actions)
<a href="https://codeclimate.com/github/Demidb/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/522cd74e06f4ba19bd53/maintainability" /></a> 

brain-even test:  https://asciinema.org/a/uN4r5k0adWDkM8Pd7zdLTC465

brain-calc test: https://asciinema.org/a/0Q41SHJZqXHSDSG8kYbl6aNwk

brain-gcd test: https://asciinema.org/a/iUxAaPbKWFHfF1B5NnuQ8gmcd

brain-progression test: https://asciinema.org/a/P1Hg9MHKbXULw3h7h6X5GZuKc

brain-prime test: https://asciinema.org/a/19JJpE6UrRleI4VQnVPLO8UPU